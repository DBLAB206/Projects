# Bridge

교량 부착 아두이노 시리얼 데이터 가공 및 저장

## 🔅 시작

```
> npm i --save-dev
```

```
> ./bat/build.bat (npm run build)
```

```
> ./bat/run.bat (npm start)
```

## ❗❗ 필요 사항 ❗❗

```
✅아두이노 연결 및 IDE 코드 업로드
✅아두이노 시리얼 모니터 닫기
```
