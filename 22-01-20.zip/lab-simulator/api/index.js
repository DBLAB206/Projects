const router = require("express").Router();

const router__REST_GET = require("./get");

router.use(router__REST_GET);

module.exports = router;
