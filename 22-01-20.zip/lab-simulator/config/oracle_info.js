exports.config__oracle_info = {
  user: process.env.DB_ORACLE__XE__USER,
  password: process.env.DB_ORACLE__XE__PASSWORD,
  connectString: process.env.DB_ORACLE__XE__CONNECTIONSTRING,
  events: true,
};
