
var sse;
function a() {
    sse = 1;    
}
a();
console.log(sse);