CREATE SEQUENCE general_seq
       INCREMENT BY 1
       START WITH 0
       MINVALUE 0
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       ORDER;