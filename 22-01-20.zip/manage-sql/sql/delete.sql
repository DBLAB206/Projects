-- 모든 테이블 삭제

-- 출력용 테이블
DROP TABLE sec_show purge;

-- 오류 기록용 테이블
DROP TABLE sec_error purge;

-- 기록용 테이블
DROP TABLE secNall purge;
DROP TABLE sec1all purge;
DROP TABLE sec2all purge;
DROP TABLE sec3all purge;
DROP TABLE sec4all purge;
DROP TABLE sec5all purge;
DROP TABLE sec6all purge;
DROP TABLE sec7all purge;

DROP TABLE sec0s1 purge;
DROP TABLE sec0s2 purge;
DROP TABLE sec0s3 purge;
DROP TABLE sec0v1 purge;
DROP TABLE sec0v2 purge;
DROP TABLE sec0v3 purge;

DROP TABLE sec1s1 purge;
DROP TABLE sec1s2 purge;
DROP TABLE sec1s3 purge;
DROP TABLE sec1v1 purge;
DROP TABLE sec1v2 purge;
DROP TABLE sec1v3 purge;

DROP TABLE sec2s1 purge;
DROP TABLE sec2s2 purge;
DROP TABLE sec2s3 purge;
DROP TABLE sec2v1 purge;
DROP TABLE sec2v2 purge;
DROP TABLE sec2v3 purge;

DROP TABLE sec3s1 purge;
DROP TABLE sec3s2 purge;
DROP TABLE sec3s3 purge;
DROP TABLE sec3v1 purge;
DROP TABLE sec3v2 purge;
DROP TABLE sec3v3 purge;